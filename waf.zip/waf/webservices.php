<?php



//include "config.php";

date_default_timezone_set('Asia/Kolkata');




function lawyer_registration($conn)

{


}

///////////////////////////////////////////////



function session_check($conn)

{

   print_r($_SESSION);

}



///////////////////////////////////////////////

?>